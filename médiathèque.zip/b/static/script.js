document.getElementById("sendBtn").addEventListener("click", () => {
    const name = document.getElementById("nameInput").value;

    fetch('/api/message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: name })
    })
    .then(response => response.json())
    .then(data => {
        const container = document.getElementById("labelContainer");
        container.innerHTML = '';
        
        data.items.forEach(item => {
            const label = document.createElement("div");
            label.textContent = item.name;
            label.className = "block";
            container.appendChild(label);
            const statusButton = document.createElement("button");
            statusButton.textContent = item.status ? "Disponible" : "Emprunté";
            statusButton.className = item.status ? "available" : "unavailable";
            statusButton.classList.add("status-button");
            statusButton.classList.add(item.status ? "available" : "unavailable");
            //if (!item.status) {statusButton.disabled = true;}
            statusButton.addEventListener("click", () => {
                fetch('/api/status', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: item.id, status: !item.status })
                })
                .then(response => response.json())
                .then(() => {
                    item.status = !item.status;
                    statusButton.className = item.status ? "available" : "unavailable";
                    statusButton.classList.add("status-button");
                    statusButton.classList.add(item.status ? "available" : "unavailable");
                    statusButton.textContent = item.status ? "Disponible" : "Emprunté";
                    //statusButton.disabled = true;
                })
            });
            label.appendChild(statusButton);
        });
    })
    .catch(error => console.error('Erreur:', error));
});

document.getElementById("adminBtn").addEventListener("click", () => {
    const name = document.getElementById("nameInput").value;

    fetch('/api/message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: name })
    })
    .then(response => response.json())
    .then(data => {
        const container = document.getElementById("labelContainer");
        container.innerHTML = '';
        
        data.items.forEach(item => {
            if (item.status === true) { return; }
            const label = document.createElement("div");
            label.textContent = item.name;
            label.className = "block";
            container.appendChild(label);
            /*
            const Title = document.createElement("div");
            Title.textContent = item.name;
            Title.className = "book-title";
            label.appendChild(Title);
            */
            const statusButton = document.createElement("button");
            statusButton.textContent = item.status ? "Rendu" : "Rendre";
            statusButton.className = item.status ? "returned" : "waiting-return";
            statusButton.classList.add("status-button");
            statusButton.classList.add(item.status ? "returned" : "waiting-return");
            statusButton.addEventListener("click", () => {
                fetch('/api/status', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: item.id, status: !item.status })
                })
                .then(response => response.json())
                .then(() => {
                    item.status = !item.status;
                    statusButton.className = item.status ? "returned" : "waiting-return";
                    statusButton.classList.add("status-button");
                    statusButton.classList.add(item.status ? "returned" : "waiting-return");
                    statusButton.textContent = item.status ? "Rendu" : "Rendre";
                })
            });
            label.appendChild(statusButton);
        });
    })
    .catch(error => console.error('Erreur:', error));
});